# NeOrigin Specs Fix (OriginOS 5 & 6)

Companion LSPosed module that fixes **NeOrigin -> About Phone -> Hardware Specs Spoofing** on OriginOS 5 & 6 (including MediaTek Dimensity / non-Snapdragon devices like iQOO Z10x).

## How it works
- Reads directly from NeOrigin's existing config (`content://com.nefanizzz.neorigin.provider/texts` and `about_phone_enabled`).
- Keep entering your desired values in **NeOrigin -> About Phone -> Hardware Specs Spoofing -> APPLY CHANGES** as usual.
- Hooks `com.android.settings` via:
  1. `Preference.setSummary` (both AndroidX & framework) by preference key and label.
  2. `TextView.setText` + About Phone view-tree scan using resource ID names, sibling card labels, and value patterns (MediaTek/Dimensity, Snapdragon, RAM, Storage, Battery).
  3. `SystemProperties.get` for both Device Model (`ro.product.model`, `ro.vivo.market.name`, etc.) and SoC (`ro.soc.model`, `ro.vivo.cpu.name`).

## Build via GitHub Actions (from Termux)
1. Unzip `NeOriginSpecsFix.zip` and push to a new GitHub repo.
2. GitHub Actions automatically builds `app-debug.apk` under **Actions -> Build NeOriginSpecsFix APK**.
3. Install the APK, enable **NeOrigin Specs Fix** in **LSPosed** with scope **Settings (`com.android.settings`)**, and force-stop Settings once.
