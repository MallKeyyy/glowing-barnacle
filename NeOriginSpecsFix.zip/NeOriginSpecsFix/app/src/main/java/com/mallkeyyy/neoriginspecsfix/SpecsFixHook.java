package com.mallkeyyy.neoriginspecsfix;

import android.app.Activity;
import android.app.AndroidAppHelper;
import android.app.Application;
import android.content.ContentResolver;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Companion LSPosed fix for NeOrigin's About Phone Hardware Specs Spoofing.
 * Reads directly from NeOrigin's ContentProvider (content://com.nefanizzz.neorigin.provider/texts)
 * so you keep using NeOrigin's existing UI ("About Phone -> APPLY CHANGES").
 */
public class SpecsFixHook implements IXposedHookLoadPackage {

    private static final String TAG = "NeOriginSpecsFix: ";
    private static final String SETTINGS_PKG = "com.android.settings";
    private static final Uri URI_CONFIG = Uri.parse("content://com.nefanizzz.neorigin.provider/settings");
    private static final Uri URI_TEXTS = Uri.parse("content://com.nefanizzz.neorigin.provider/texts");

    private static final long RELOAD_INTERVAL_MS = 2000L;

    private static volatile long sLastLoadTime = 0L;
    private static volatile boolean sEnabled = true;
    private static volatile boolean sInAboutPhone = false;
    private static volatile String sRealModel = Build.MODEL != null ? Build.MODEL : "";
    private static volatile String sRealMarketName = "";
    private static volatile String sRealSoc = "";

    private static final Map<String, String> sSpecFields = new ConcurrentHashMap<>();
    private static final Map<String, String> sTextReplacements = new ConcurrentHashMap<>();

    // Patterns for fallback matching ONLY while on the About Phone screen
    private static final Pattern PAT_CPU = Pattern.compile(
            "(?i)(dimensity|snapdragon|mediatek|qualcomm|exynos|tensor|kirin|helio|mt6\\d{3}|sm8\\d{3}|sm7\\d{3}|octa[- ]?core|天玑|骁龙)");
    private static final Pattern PAT_RAM = Pattern.compile(
            "(?i)^\\d+\\s*GB\\s*(\\+\\s*\\d+\\s*GB)?(\\s*RAM)?$");
    private static final Pattern PAT_STORAGE = Pattern.compile(
            "(?i)(\\d+(\\.\\d+)?\\s*(GB|TB)\\s*/\\s*\\d+\\s*(GB|TB)|^\\d+\\s*(GB|TB)\\s*(ROM|UFS)?$)");
    private static final Pattern PAT_BATTERY = Pattern.compile(
            "(?i)^\\d{4,5}\\s*mAh(\\s*\\(.*\\))?$");

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!SETTINGS_PKG.equals(lpparam.packageName)) {
            return;
        }

        XposedBridge.log(TAG + "Loaded into com.android.settings");
        captureOriginalSystemProps(lpparam.classLoader);

        hookActivityLifecycle();
        hookSystemProperties(lpparam.classLoader);
        hookPreferences(lpparam.classLoader);
        hookTextView();
        hookViewTreeOnResume();
    }

    private void captureOriginalSystemProps(ClassLoader cl) {
        try {
            Class<?> sp = XposedHelpers.findClass("android.os.SystemProperties", cl);
            String market = (String) XposedHelpers.callStaticMethod(sp, "get", "ro.vivo.market.name", "");
            if (market != null && !market.isEmpty()) sRealMarketName = market;
            String soc = (String) XposedHelpers.callStaticMethod(sp, "get", "ro.soc.model", "");
            if (soc == null || soc.isEmpty()) {
                soc = (String) XposedHelpers.callStaticMethod(sp, "get", "ro.vivo.cpu.name", "");
            }
            if (soc != null && !soc.isEmpty()) sRealSoc = soc;
        } catch (Throwable ignored) {
        }
    }

    private void hookActivityLifecycle() {
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onResume", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Activity act = (Activity) param.thisObject;
                    String clsName = act.getClass().getName().toLowerCase(Locale.ROOT);
                    String title = act.getTitle() != null ? act.getTitle().toString().toLowerCase(Locale.ROOT) : "";
                    boolean isAbout = isAboutPhoneScreen(clsName, title);
                    sInAboutPhone = isAbout;
                    if (isAbout) {
                        reloadConfig(true);
                        // Also scan the already-inflated view tree after layout
                        View decor = act.getWindow() != null ? act.getWindow().getDecorView() : null;
                        if (decor != null) {
                            decor.post(() -> scanAndPatchViewTree(decor));
                            decor.postDelayed(() -> scanAndPatchViewTree(decor), 300);
                        }
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "Failed hooking Activity.onResume: " + t);
        }
    }

    private void hookViewTreeOnResume() {
        // Also catch Fragment resumes (OriginOS Settings uses SubSettings + VivoAboutPhoneFragment)
        String[] fragmentClasses = {
                "androidx.fragment.app.Fragment",
                "android.app.Fragment"
        };
        for (String fc : fragmentClasses) {
            try {
                Class<?> cls = XposedHelpers.findClassIfExists(fc, AndroidAppHelper.currentApplication() != null
                        ? AndroidAppHelper.currentApplication().getClassLoader() : null);
                if (cls == null) continue;
                XposedHelpers.findAndHookMethod(cls, "onResume", new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        String name = param.thisObject.getClass().getName().toLowerCase(Locale.ROOT);
                        if (isAboutPhoneScreen(name, "")) {
                            sInAboutPhone = true;
                            reloadConfig(true);
                            try {
                                View root = (View) XposedHelpers.callMethod(param.thisObject, "getView");
                                if (root != null) {
                                    root.post(() -> scanAndPatchViewTree(root));
                                    root.postDelayed(() -> scanAndPatchViewTree(root), 350);
                                }
                            } catch (Throwable ignored) {
                            }
                        }
                    }
                });
            } catch (Throwable ignored) {
            }
        }
    }

    private void hookSystemProperties(ClassLoader cl) {
        try {
            Class<?> sp = XposedHelpers.findClass("android.os.SystemProperties", cl);
            XposedBridge.hookAllMethods(sp, "get", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    if (param.args == null || param.args.length == 0 || !(param.args[0] instanceof String)) {
                        return;
                    }
                    String key = (String) param.args[0];
                    reloadConfig(false);
                    if (!sEnabled || sSpecFields.isEmpty()) return;

                    if (key.equals("ro.product.model")
                            || key.equals("ro.vivo.market.name")
                            || key.equals("ro.vivo.product.model")
                            || key.equals("ro.product.device")
                            || key.equals("ro.product.marketname")) {
                        String dev = sSpecFields.get("device");
                        if (dev != null && !dev.isEmpty()) {
                            param.setResult(dev);
                        }
                    } else if (key.equals("ro.soc.model")
                            || key.equals("ro.vivo.cpu.name")
                            || key.equals("ro.vivo.hardware.cpu")
                            || key.equals("ro.hardware.chipname")) {
                        String cpu = sSpecFields.get("cpu");
                        if (cpu != null && !cpu.isEmpty()) {
                            param.setResult(cpu);
                        }
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "Failed hooking SystemProperties: " + t);
        }
    }

    private void hookPreferences(ClassLoader cl) {
        String[] prefClasses = {
                "androidx.preference.Preference",
                "android.preference.Preference"
        };
        for (String prefClsName : prefClasses) {
            try {
                Class<?> prefCls = XposedHelpers.findClassIfExists(prefClsName, cl);
                if (prefCls == null) continue;
                XposedHelpers.findAndHookMethod(prefCls, "setSummary", CharSequence.class, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        if (param.args == null || param.args.length == 0 || param.args[0] == null) return;
                        reloadConfig(false);
                        if (!sEnabled || (sSpecFields.isEmpty() && sTextReplacements.isEmpty())) return;

                        String key = "";
                        String title = "";
                        try {
                            Object k = XposedHelpers.callMethod(param.thisObject, "getKey");
                            if (k != null) key = k.toString();
                            Object t = XposedHelpers.callMethod(param.thisObject, "getTitle");
                            if (t != null) title = t.toString();
                        } catch (Throwable ignored) {
                        }

                        String specKey = classifyByKeyOrLabel(key, title);
                        if (specKey != null) {
                            String spoof = sSpecFields.get(specKey);
                            if (spoof != null && !spoof.isEmpty()) {
                                param.args[0] = spoof;
                                return;
                            }
                        }

                        String orig = param.args[0].toString();
                        String replaced = applyTextReplacement(orig);
                        if (!replaced.equals(orig)) {
                            param.args[0] = replaced;
                        }
                    }
                });
                XposedBridge.log(TAG + "Hooked " + prefClsName + ".setSummary");
            } catch (Throwable t) {
                XposedBridge.log(TAG + "Failed hooking " + prefClsName + ": " + t);
            }
        }
    }

    private void hookTextView() {
        try {
            XposedHelpers.findAndHookMethod(
                    TextView.class, "setText",
                    CharSequence.class, TextView.BufferType.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            if (param.args == null || param.args.length == 0 || param.args[0] == null) return;
                            CharSequence cs = (CharSequence) param.args[0];
                            if (cs.length() == 0) return;

                            reloadConfig(false);
                            if (!sEnabled || (sSpecFields.isEmpty() && sTextReplacements.isEmpty())) return;

                            TextView tv = (TextView) param.thisObject;
                            String text = cs.toString();

                            // 1. Check view resource ID name (works even before layout)
                            String resName = getResEntryName(tv);
                            String specKey = classifyByViewId(resName);

                            // 2. Check sibling label inside About Phone card
                            if (specKey == null && sInAboutPhone) {
                                String siblingLabel = findSiblingLabel(tv);
                                if (siblingLabel != null) {
                                    specKey = classifyByKeyOrLabel("", siblingLabel);
                                }
                            }

                            // 3. Pattern fallback strictly when inside About Phone
                            if (specKey == null && sInAboutPhone) {
                                specKey = classifyByValuePattern(text);
                            }

                            if (specKey != null) {
                                String spoof = sSpecFields.get(specKey);
                                if (spoof != null && !spoof.isEmpty() && !spoof.equals(text)) {
                                    param.args[0] = spoof;
                                    return;
                                }
                            }

                            // 4. Direct text replacement map fallback
                            String replaced = applyTextReplacement(text);
                            if (!replaced.equals(text)) {
                                param.args[0] = replaced;
                            }
                        }
                    });
            XposedBridge.log(TAG + "Hooked TextView.setText");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "Failed hooking TextView.setText: " + t);
        }
    }

    private void scanAndPatchViewTree(View root) {
        if (!sEnabled || sSpecFields.isEmpty() || root == null) return;
        if (root instanceof TextView) {
            TextView tv = (TextView) root;
            CharSequence cs = tv.getText();
            if (cs != null && cs.length() > 0) {
                String text = cs.toString();
                String specKey = classifyByViewId(getResEntryName(tv));
                if (specKey == null) {
                    String sibling = findSiblingLabel(tv);
                    if (sibling != null) specKey = classifyByKeyOrLabel("", sibling);
                }
                if (specKey == null) {
                    specKey = classifyByValuePattern(text);
                }
                if (specKey != null) {
                    String spoof = sSpecFields.get(specKey);
                    if (spoof != null && !spoof.isEmpty() && !spoof.equals(text)) {
                        tv.setText(spoof);
                    }
                }
            }
        } else if (root instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) root;
            for (int i = 0; i < vg.getChildCount(); i++) {
                scanAndPatchViewTree(vg.getChildAt(i));
            }
        }
    }

    private static boolean isAboutPhoneScreen(String className, String title) {
        return className.contains("aboutphone")
                || className.contains("about_phone")
                || className.contains("deviceinfo")
                || className.contains("mydevice")
                || className.contains("hardwareinfo")
                || className.contains("vivodevice")
                || title.contains("about phone")
                || title.contains("about device")
                || title.contains("关于手机")
                || title.contains("о телефоне")
                || title.contains("tentang telefon")
                || title.contains("thông tin điện thoại");
    }

    private static String getResEntryName(View v) {
        int id = v.getId();
        if (id == View.NO_ID || id <= 0) return "";
        try {
            Resources r = v.getResources();
            if (r != null) return r.getResourceEntryName(id);
        } catch (Throwable ignored) {
        }
        return "";
    }

    private static String findSiblingLabel(TextView target) {
        ViewParent parent = target.getParent();
        if (!(parent instanceof ViewGroup)) return null;
        ViewGroup vg = (ViewGroup) parent;
        if (vg.getChildCount() > 6) return null; // avoid unrelated large containers

        String targetText = target.getText() != null ? target.getText().toString() : "";
        for (int i = 0; i < vg.getChildCount(); i++) {
            View child = vg.getChildAt(i);
            if (child == target) continue;
            if (child instanceof TextView) {
                CharSequence cs = ((TextView) child).getText();
                if (cs != null && cs.length() > 0 && !cs.toString().equals(targetText)) {
                    String label = cs.toString();
                    // Only treat short label-like strings as titles
                    if (label.length() <= 32 && classifyByKeyOrLabel("", label) != null) {
                        return label;
                    }
                }
            }
        }
        return null;
    }

    private static String classifyByViewId(String resName) {
        if (resName == null || resName.isEmpty()) return null;
        String id = resName.toLowerCase(Locale.ROOT);
        // Never overwrite title labels themselves
        if (id.contains("title") || id.contains("label") || id.contains("header")) return null;

        if (id.contains("cpu") || id.contains("processor") || id.contains("soc")) return "cpu";
        if (id.contains("ram") || id.contains("running_memory") || id.contains("mem_size")) return "ram";
        if (id.contains("rom") || id.contains("storage")) return "storage";
        if (id.contains("battery")) return "battery";
        if (id.contains("model") || id.contains("device_name") || id.contains("market_name")) return "device";
        if (id.contains("chip") || id.contains("gpu") || id.contains("npu") || id.contains("v_chip")) return "chip";
        return null;
    }

    private static String classifyByKeyOrLabel(String key, String label) {
        String k = (key != null ? key : "").toLowerCase(Locale.ROOT);
        String l = (label != null ? label : "").toLowerCase(Locale.ROOT);

        if (k.contains("cpu") || k.contains("processor") || k.contains("soc")
                || l.equals("processor") || l.equals("cpu") || l.contains("处理器") || l.contains("процессор") || l.contains("pemproses")) {
            return "cpu";
        }
        if (k.contains("ram") || k.contains("memory")
                || l.equals("ram") || l.contains("运行内存") || l.equals("озу") || l.contains("оперативная память")) {
            return "ram";
        }
        if (k.contains("rom") || k.contains("storage")
                || l.equals("storage") || l.equals("phone storage") || l.contains("手机存储") || l.contains("хранилище") || l.contains("storan")) {
            return "storage";
        }
        if (k.contains("battery")
                || l.equals("battery") || l.equals("battery capacity") || l.contains("电池") || l.contains("аккумулятор") || l.contains("bateri")) {
            return "battery";
        }
        if (k.contains("model") || k.contains("device_name") || k.contains("product_model")
                || l.equals("model") || l.equals("device name") || l.contains("型号") || l.contains("设备名称") || l.contains("модель")) {
            return "device";
        }
        if (k.contains("chip") || k.contains("gpu") || k.contains("npu")
                || l.contains("graphic chip") || l.contains("imaging chip") || l.contains("npu") || l.contains("芯片") || l.contains("графический")) {
            return "chip";
        }
        return null;
    }

    private static String classifyByValuePattern(String text) {
        if (text == null || text.isEmpty() || text.length() > 80) return null;
        // Skip known labels
        if (classifyByKeyOrLabel("", text) != null) return null;

        if ((!sRealModel.isEmpty() && text.equals(sRealModel))
                || (!sRealMarketName.isEmpty() && text.equals(sRealMarketName))) {
            return "device";
        }
        if ((!sRealSoc.isEmpty() && text.contains(sRealSoc)) || PAT_CPU.matcher(text).find()) {
            return "cpu";
        }
        if (PAT_RAM.matcher(text).matches()) {
            return "ram";
        }
        if (PAT_STORAGE.matcher(text).find()) {
            return "storage";
        }
        if (PAT_BATTERY.matcher(text).matches()) {
            return "battery";
        }
        return null;
    }

    private static String applyTextReplacement(String input) {
        if (sTextReplacements.isEmpty() || input == null) return input;
        String exact = sTextReplacements.get(input);
        if (exact != null) return exact;
        String out = input;
        for (Map.Entry<String, String> e : sTextReplacements.entrySet()) {
            String k = e.getKey();
            if (k != null && k.length() >= 3 && out.contains(k)) {
                out = out.replace(k, e.getValue());
            }
        }
        return out;
    }

    private static synchronized void reloadConfig(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && (now - sLastLoadTime) < RELOAD_INTERVAL_MS) {
            return;
        }
        sLastLoadTime = now;

        Application app = AndroidAppHelper.currentApplication();
        if (app == null) return;
        ContentResolver cr = app.getContentResolver();
        if (cr == null) return;

        // 1. Check about_phone_enabled from NeOrigin ConfigProvider
        try {
            Bundle cfg = cr.call(URI_CONFIG, "get", null, null);
            if (cfg != null && cfg.containsKey("about_phone_enabled")) {
                sEnabled = cfg.getBoolean("about_phone_enabled", true);
            }
        } catch (Throwable ignored) {
        }

        if (!sEnabled) {
            sSpecFields.clear();
            sTextReplacements.clear();
            return;
        }

        // 2. Read NeOrigin's banner_texts.txt
        try (InputStream is = cr.openInputStream(URI_TEXTS)) {
            if (is == null) return;
            sSpecFields.clear();
            sTextReplacements.clear();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty() || line.startsWith("#")) continue;
                    String[] parts = line.split("==", 2);
                    if (parts.length != 2) continue;
                    String k = parts[0].trim();
                    String v = parts[1].trim();
                    if (k.isEmpty() || v.isEmpty()) continue;

                    if (k.equalsIgnoreCase("device") || k.equalsIgnoreCase("model")) {
                        sSpecFields.put("device", v);
                    } else if (k.equalsIgnoreCase("cpu") || k.equalsIgnoreCase("processor")) {
                        sSpecFields.put("cpu", v);
                    } else if (k.equalsIgnoreCase("ram")) {
                        sSpecFields.put("ram", v);
                    } else if (k.equalsIgnoreCase("storage") || k.equalsIgnoreCase("rom")) {
                        sSpecFields.put("storage", v);
                    } else if (k.equalsIgnoreCase("battery")) {
                        sSpecFields.put("battery", v);
                    } else if (k.equalsIgnoreCase("chip")) {
                        sSpecFields.put("chip", v);
                    } else {
                        sTextReplacements.put(k, v);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }
}
